"""Analytics providers module."""

from .basic import BasicAnalyticsProvider

__all__ = ["BasicAnalyticsProvider"]