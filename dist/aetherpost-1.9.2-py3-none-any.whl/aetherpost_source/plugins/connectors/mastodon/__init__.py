"""Mastodon connector module."""

from .connector import MastodonConnector

__all__ = ["MastodonConnector"]