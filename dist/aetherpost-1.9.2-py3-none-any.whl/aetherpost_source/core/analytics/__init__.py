"""Analytics and insights modules."""

from .dashboard import AnalyticsDashboard

__all__ = ["AnalyticsDashboard"]