"""Main module for running AetherPost as a package."""

from .cli.main import app

if __name__ == "__main__":
    app()