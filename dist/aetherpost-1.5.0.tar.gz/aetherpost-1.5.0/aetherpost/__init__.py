"""AetherPost - Promotion as Code

Automate your app promotion across social media platforms.
"""

__version__ = "1.5.0"
__author__ = "AetherPost Team"
__email__ = "team@autopromo.dev"