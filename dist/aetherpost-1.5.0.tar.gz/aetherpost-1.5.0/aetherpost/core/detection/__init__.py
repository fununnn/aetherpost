"""Project detection utilities."""

from .git_detector import GitDetector

__all__ = ["GitDetector"]