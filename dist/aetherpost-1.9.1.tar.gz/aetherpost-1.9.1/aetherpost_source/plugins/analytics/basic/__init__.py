"""Basic analytics provider module."""

from .provider import BasicAnalyticsProvider

__all__ = ["BasicAnalyticsProvider"]